# Pwn The Rover Qualification Challenges

In each directory is a challenge.
All challenges can be solved independently.
The solution for each challenge is a flag of the format:

```
PTR{challenge-dependent-token}
```

For further information refer to the [website](https://pwn-the-rover.space/).

Happy Hacking!
